int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lp, LPARAM lpData) {
  if (uMsg == BFFM_INITIALIZED && lpData)
    mySendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpData);
  if (uMsg==BFFM_SELCHANGED)
  {
    SendMessage(
      hwnd,
      BFFM_ENABLEOK,
      0,
      SHGetPathFromIDList((LPITEMIDLIST)lp,(char*)lpData)
    );
  }
  return 0;
}